import org.apache.hadoop.fs.Path
import java.net.URI
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

val orgDBTable = "sshen_noncore.device_point"
val stdDBTable = "sshen_noncore.device_point_std"


val newTableDF = spark.sql("select vehicle_type as id, trip_id, unix_time, from_unixtime(CAST(unix_time AS BIGINT)) as DT, avg(speed) as speed_mps from sshen_noncore.device_point where speed>=0 group by vehicle_type, trip_id, unix_time order by unix_time")

newTableDF.write.mode("append").saveAsTable(stdDBTable)


System.exit(0)

