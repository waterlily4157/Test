import org.apache.hadoop.fs.Path
import java.net.URI
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

val calDBTable = "sshen_noncore.device_point_g"


// Calculate 1) median smoothing, 2) calculate g value in 2 seconds and 3 seconds
val newTableDF = spark.sql("select id, trip_id, unix_time, dt, date_format(dt, 'EEEE') as week_day, hour(dt) as time_hr, speed_mps from sshen_noncore.device_point_std group by id, trip_id, unix_time, dt, speed_mps order by unix_time")

//3 points window for moving average filter
val wSpec1 = Window.partitionBy("trip_id").orderBy("unix_time").rowsBetween(-1, 1)

val wSpec4 = Window.partitionBy("trip_id").orderBy("unix_time").rowsBetween(-1, 0)
val wSpec2 = Window.partitionBy("trip_id").orderBy("unix_time").rowsBetween(-2, 0)
val wSpec3 = Window.partitionBy("trip_id").orderBy("unix_time").rowsBetween(-3, 0)

//Smoothing with 3 points movibg average
val std_pointDF = newTableDF.withColumn( "speed_smooth", avg(newTableDF("speed_mps")).over(wSpec1) )

val std_pointDF2 = std_pointDF.withColumn( "speed_mph", std_pointDF("speed_smooth")/0.44704 )

val g1_pointDF = std_pointDF2.withColumn( "g1s", (last(std_pointDF2("speed_smooth")).over(wSpec4)-first(std_pointDF2("speed_smooth")).over(wSpec4))/9.8 )

//val g2_pointDF = std_pointDF.withColumn( "g2s", (last(std_pointDF("speed_smooth")).over(wSpec2)-first(std_pointDF("speed_smooth")).over(wSpec2))/2/9.8 )

val g2_pointDF = g1_pointDF.withColumn( "g2s", (last(g1_pointDF("speed_smooth")).over(wSpec2)-first(g1_pointDF("speed_smooth")).over(wSpec2))/2/9.8 )

val g3_pointDF = g2_pointDF.withColumn( "g3s", (last(g2_pointDF("speed_smooth")).over(wSpec3)-first(g2_pointDF("speed_smooth")).over(wSpec3))/3/9.8 )

g3_pointDF.write.mode("append").saveAsTable(calDBTable)

System.exit(0)

