import org.apache.hadoop.fs.Path
import java.net.URI
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration

val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

//val uri = new URI("hdfs://discovery:8020")
val uri = new URI("hdfs://localhost:9000")
val fs = FileSystem.get(uri,new Configuration())   

//val filePath = new Path("/user/sshen/data/telem/")
val filePath = new Path("/data/pwang/telem/")
val dbTable = "sshen_noncore.accel_ref"

case class Accel(ref_id: String, speed_low: Float, speed_up: Float, g_low: Float, g_up: Float, weight: Float)

val fileList = fs.listStatus(filePath) 

fileList.foreach { file =>

        println("CSV File = " + file.getPath().toString() )
        val fileWithPath = file.getPath().toString()

        val rawTextRDD = sc.textFile(fileWithPath)

        val header = rawTextRDD.first()
        val data = rawTextRDD.filter(row => row != header)

        val refRDD = data.map{raw_line => 
            val columns = raw_line.split(",")

            val id = "accel"

            Accel(id, columns(0).toFloat, columns(1).toFloat, columns(2).toFloat, columns(3).toFloat, columns(4).toFloat)
            
        }

        val refDF = refRDD.toDF
 
        refDF.write.mode("append").saveAsTable(dbTable)

}

System.exit(0)

