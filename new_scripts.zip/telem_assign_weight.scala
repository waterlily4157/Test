import org.apache.hadoop.fs.Path
import java.net.URI
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

val calDBTable = "sshen_noncore.device_point_g"

val accelDBTable = "sshen_noncore.accel_weight"
val decelDBTable = "sshen_noncore.decel_weight"
val timeDBTable = "sshen_noncore.time_weight"
val speedDBTable = "sshen_noncore.speeding_weight"


// assign weight for accel
val accelTableDF = spark.sql("select a.id as VID, a.trip_id as TRIP_ID, a.unix_time as UX_TIME, a.speed_mph as SPEED, a.g1s AS g, b.weight as WEIGHT from sshen_noncore.device_point_g a, sshen_noncore.accel_ref b where a.g1s >=0 and (a.speed_mph >= b.speed_low and a.speed_mph  <= b.speed_up) and (a.g1s>=b.g_low and a.g1s<=b.g_up)")

accelTableDF.write.mode("append").saveAsTable(accelDBTable)

// assign weight for decel
val decelTableDF = spark.sql("select a.id as VID, a.trip_id as TRIP_ID, a.unix_time as UX_TIME, a.speed_mph as SPEED, a.g1s AS g, b.weight as WEIGHT  from sshen_noncore.device_point_g a, sshen_noncore.decel_ref b where a.g1s <=0 and (a.speed_mph >= b.speed_low and a.speed_mph  <= b.speed_up) and (a.g1s>=b.g_low and a.g1s<=b.g_up)")

decelTableDF.write.mode("append").saveAsTable(decelDBTable)

// assign weight for time on week day
val timeTableDF = spark.sql("select a.id as VID, a.trip_id as TRIP_ID, a.unix_time as UX_TIME, a.speed_mph as SPEED, a.week_day as WEEK_DAY, a.time_hr as Hour, b.weight as WEIGHT from sshen_noncore.device_point_g a, sshen_noncore.time_ref b where (substring(a.week_day, 0, 3) = b.week_day) and (a.time_hr>=b.h_low and a.time_hr<=b.h_up)")

timeTableDF.write.mode("append").saveAsTable(timeDBTable)

// assign weight = 5675.0 when speed >= 80

val speedTableDF = spark.sql("select id as VID, trip_id, unix_time as UX_TIME, speed_mph as SPEED, case when speed_mph>=80 then 5675.0 else 0.0 end as WEIGHT from sshen_noncore.device_point_g")

speedTableDF.write.mode("append").saveAsTable(speedDBTable)

System.exit(0)

